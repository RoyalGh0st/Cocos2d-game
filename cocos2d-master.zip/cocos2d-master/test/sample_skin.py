
skin = [
    ('brazo izq', (10, 49), 'gil-brazo2.png', False, False, 0.5),
    ('antebrazo izq', (9, 47), 'gil-mano2.png', False, False, 0.5),
    ('muslo izq', (10, 55), 'gil-pierna2.png', False, False, 0.5),
    ('pierna izq', (10, 75), 'gil-bota2.png', False, False, 0.5),
    ('cabeza', (31, 44), 'gil-peluca.png', True, True, 0.5),
    ('torso', (25, 91), 'gil-cuerpo.png', True, True, 0.5),
    ('cabeza', (16, 18), 'gil-cara.png', True, True, 0.5),
    ('brazo der', (12, 40), 'gil-brazo1.png', False, False, 0.5),
    ('antebrazo der', (11, 51), 'gil-mano1.png', False, False, 0.5),
    ('muslo der', (10, 55), 'gil-pierna1.png', False, False, 0.5),
    ('pierna der', (15, 67), 'gil-bota1.png', False, False, 0.5),
  ]
