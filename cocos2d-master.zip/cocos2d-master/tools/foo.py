from cocos.path import Bezier

curva = Bezier( (297,297), (13,286), (-192, 272), (89,84) )
